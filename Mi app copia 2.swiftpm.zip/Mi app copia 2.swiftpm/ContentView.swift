import SwiftUI
struct ContentView: View {
    @State private var nivelGlucosa = ""
    @State private var categoriasAlimentosSeleccionadas: [CategoriaAlimento] = []
    @State private var categoriasComidaSeleccionadas: [CategoriaComida] = []
    @State private var tipoDiabetesSeleccionado: TipoDiabetes?
    @State private var fechaSeleccionada = Date()
    @State private var nombre = ""
    @State private var edad = ""
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy 'a las' h:mm a"
        formatter.timeZone = TimeZone(identifier: "America/Tijuana")
        return formatter
    }
    var body: some View {
        VStack(spacing: 6) {
            Text("DiabControl+").font(.title).foregroundColor(.green)
            Image(systemName: "leaf.fill").resizable().aspectRatio(contentMode: .fit).frame(width: 20, height: 20).foregroundColor(.green)
            
            Text("Introduce tu tipo de Diabetes:").font(.headline).foregroundColor(.purple)
            HStack {
                ForEach(TipoDiabetes.allCases, id: \.self) { tipo in
                    VistaCategoria(categoria: .diabetes(tipo), categoriasAlimentosSeleccionadas: $categoriasAlimentosSeleccionadas, categoriasComidaSeleccionadas: $categoriasComidaSeleccionadas, tipoDiabetesSeleccionado: $tipoDiabetesSeleccionado)
                        .frame(maxWidth: .infinity).contentShape(Rectangle())
                }
            }.padding()
            Text("Diabetes Seleccionada: \(tipoDiabetesSeleccionado?.rawValue.capitalized ?? "")").foregroundColor(.purple)
            Text("Introduce tu nombre").font(.headline).foregroundColor(.cyan)
            TextField("Nombre", text: $nombre).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            Text("Introduce tu edad").font(.headline).foregroundColor(.cyan)
            TextField("Edad", text: $edad).textFieldStyle(RoundedBorderTextFieldStyle()).keyboardType(.numberPad).padding()
            Text("¿Cuál es tu nivel de glucosa?").font(.headline).foregroundColor(.cyan)
            TextField("Nivel de Glucosa", text: $nivelGlucosa).textFieldStyle(RoundedBorderTextFieldStyle()).keyboardType(.numberPad).padding()
            DatePicker("Fecha de Registro", selection: $fechaSeleccionada, in: ...Date(), displayedComponents: [.date]).datePickerStyle(WheelDatePickerStyle()).padding()
            Text("¿Qué comiste hoy?").font(.headline).foregroundColor(.blue)
            LazyVGrid(columns: Array(repeating: GridItem(), count: 3), spacing: 6) {
                ForEach(CategoriaAlimento.allCases, id: \.self) { categoria in
                    VistaCategoria(categoria: .alimento(categoria), categoriasAlimentosSeleccionadas: $categoriasAlimentosSeleccionadas, categoriasComidaSeleccionadas: $categoriasComidaSeleccionadas, tipoDiabetesSeleccionado: $tipoDiabetesSeleccionado)
                }
            }
            Text("¿Qué comida del día fue?").font(.headline).foregroundColor(.orange)
            LazyVGrid(columns: Array(repeating: GridItem(), count: 3), spacing: 6) {
                ForEach(CategoriaComida.allCases, id: \.self) { categoria in
                    VistaCategoria(categoria: .comida(categoria), categoriasAlimentosSeleccionadas: $categoriasAlimentosSeleccionadas, categoriasComidaSeleccionadas: $categoriasComidaSeleccionadas, tipoDiabetesSeleccionado: $tipoDiabetesSeleccionado)
                }
            }.padding()
            Text("Categorías de Alimentos: \(categoriasAlimentosSeleccionadas.map { $0.rawValue.capitalized }.joined(separator: ", "))").foregroundColor(.blue)
            if !categoriasComidaSeleccionadas.isEmpty || !categoriasAlimentosSeleccionadas.isEmpty {
                Text("Categorías de Comida: \(categoriasComidaSeleccionadas.map { $0.rawValue.capitalized }.joined(separator: ", "))").foregroundColor(.orange)
            } else {
                Text("Categorías de Comida: ").foregroundColor(.orange)
            }
            Button("Registrar Entrada") { registrarEntrada() }.buttonStyle(EstiloBotonGradiente()).padding()
            Spacer()
        }.padding(6)
    }
    func registrarEntrada() {
        let formattedDate = fechaSeleccionada.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT(for: fechaSeleccionada)))
        print("Fecha de Registro: \(formattedDate)")
        print("Nombre: \(nombre)")
        print("Edad: \(edad)")
        print("Nivel de Glucosa: \(nivelGlucosa)")
        print("Categorías de Alimentos: \(categoriasAlimentosSeleccionadas.map { $0.rawValue })")
        print("Categorías de Comida: \(categoriasComidaSeleccionadas.map { $0.rawValue })")
        print("Tipo de Diabetes: \(tipoDiabetesSeleccionado?.rawValue ?? "")")
        nivelGlucosa = ""
        categoriasAlimentosSeleccionadas = []
        categoriasComidaSeleccionadas = []
        tipoDiabetesSeleccionado = nil
        nombre = ""
        edad = ""
    }
}
struct VistaCategoria: View {
    var categoria: Categoria
    @Binding var categoriasAlimentosSeleccionadas: [CategoriaAlimento]
    @Binding var categoriasComidaSeleccionadas: [CategoriaComida]
    @Binding var tipoDiabetesSeleccionado: TipoDiabetes?
    var body: some View {
        VStack(spacing: 2) {
            Image(systemName: categoria.icono)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 20, height: 20)
                .foregroundColor(iconColor)
                .opacity(opacidadSeleccionada)
                .padding(2)
                .cornerRadius(4.0)
            Text(categoria.rawValue.capitalized)
                .font(.caption)
                .foregroundColor(textColor)
        }
        .onTapGesture {
            toggleSeleccion(categoria)
        }
    }
    private var iconColor: Color {
        switch categoria {
        case .alimento(let categoriaAlimento):
            return categoriasAlimentosSeleccionadas.contains(categoriaAlimento) ? .blue : .gray
        case .comida(let categoriaComida):
            return categoriasComidaSeleccionadas.contains(categoriaComida) ? .orange : .gray
        case .diabetes(let tipoDiabetes):
            return tipoDiabetesSeleccionado == tipoDiabetes ? .purple : .gray
        }
    }
    private var textColor: Color {
        switch categoria {
        case .alimento:
            return .blue
        case .comida:
            return .orange
        case .diabetes:
            return .purple
        }
    }
    private func toggleSeleccion(_ categoria: Categoria) {
        switch categoria {
        case .alimento(let categoriaAlimento):
            if let indice = categoriasAlimentosSeleccionadas.firstIndex(of: categoriaAlimento) {
                categoriasAlimentosSeleccionadas.remove(at: indice)
            } else {
                categoriasAlimentosSeleccionadas.append(categoriaAlimento)
            }
        case .comida(let categoriaComida):
            if let indice = categoriasComidaSeleccionadas.firstIndex(of: categoriaComida) {
                categoriasComidaSeleccionadas.remove(at: indice)
            } else {
                categoriasComidaSeleccionadas.append(categoriaComida)
            }
        case .diabetes(let tipoDiabetes):
            tipoDiabetesSeleccionado = (tipoDiabetesSeleccionado == tipoDiabetes) ? nil : tipoDiabetes
        }
    }
    private var colorSeleccionado: Color {
        switch categoria {
        case .alimento(let categoriaAlimento):
            return categoriasAlimentosSeleccionadas.contains(categoriaAlimento) ? .blue : .gray
        case .comida(let categoriaComida):
            return categoriasComidaSeleccionadas.contains(categoriaComida) ? .orange : .gray
        case .diabetes(let tipoDiabetes):
            return tipoDiabetesSeleccionado == tipoDiabetes ? .purple : .gray
        }
    }
    private var opacidadSeleccionada: Double {
        switch categoria {
        case .alimento(let categoriaAlimento):
            return categoriasAlimentosSeleccionadas.contains(categoriaAlimento) ? 1.0 : 0.5
        case .comida(let categoriaComida):
            return categoriasComidaSeleccionadas.contains(categoriaComida) ? 1.0 : 0.5
        case .diabetes(let tipoDiabetes):
            return tipoDiabetesSeleccionado == tipoDiabetes ? 1.0 : 0.5
        }
    }
}
enum Categoria: Hashable {
    case alimento(CategoriaAlimento)
    case comida(CategoriaComida)
    case diabetes(TipoDiabetes)
    var icono: String {
        switch self {
        case .alimento(let categoriaAlimento): return categoriaAlimento.icono
        case .comida(let categoriaComida): return categoriaComida.icono
        case .diabetes(let tipoDiabetes): return tipoDiabetes.icono
        }
    }
    var rawValue: String {
        switch self {
        case .alimento(let categoriaAlimento): return categoriaAlimento.rawValue
        case .comida(let categoriaComida): return categoriaComida.rawValue
        case .diabetes(let tipoDiabetes): return tipoDiabetes.rawValue
        }
    }
    var esCategoriaComida: Bool {
        if case .comida = self {
            return true
        }
        return false
    }
}
enum CategoriaAlimento: String, CaseIterable {
    case vegetales = "vegetales"
    case frutas = "frutas"
    case cereales = "cereales"
    case proteinas = "proteínas"
    case lacteos = "lácteos"
    case grasas = "grasas"
    var icono: String {
        switch self {
        case .vegetales: return "carrot.fill"
        case .frutas: return "tree.fill"
        case .cereales: return "laurel.leading"
        case .proteinas: return "bolt.fill"
        case .lacteos: return "drop.fill"
        case .grasas: return "fish.fill"
        }
    }
}
enum CategoriaComida: String, CaseIterable {
    case desayuno = "desayuno"
    case almuerzo = "almuerzo"
    case cena = "cena"
    var icono: String {
        switch self {
        case .desayuno: return "sunrise.fill"
        case .almuerzo: return "sun.max.fill"
        case .cena: return "moon.fill"
        }
    }
}
enum TipoDiabetes: String, CaseIterable {
    case tipo1 = "Tipo 1"
    case tipo2 = "Tipo 2"
    case preDiabetes = "Pre Diabetes"
    var icono: String {
        switch self {
        case .tipo1: return "heart.fill"
        case .tipo2: return "flame.fill"
        case .preDiabetes: return "pill.fill"
        }
    }
}
struct EstiloBotonGradiente: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .padding(12)
            .foregroundColor(.white)
            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(6.0)
    }
}
struct ContenidoVista_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
